module.exports = {
    token: "8501128971:AAEO12l4gqEeiCNratP8Sh5t9_R8eR-jhb4",
    ownerId: 1662937958,
    channels: ["@kyu_info1", "@yozakura_clan", "@kyu_testi"],
    photoUrl: "https://files.catbox.moe/95ti45.jpg"
};